import { NgClass } from "@angular/common";
import { Component } from "@angular/core";

@Component({
  selector: "app-step5",
  standalone: true,
  imports: [NgClass],
  templateUrl: "./step5.component.html"
})
export class Step5Component {
  constructor() {}
}
