import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chat',
  standalone: true, // Generated Stand-Alone Component
  templateUrl: './chat.component.html',
  styleUrls: ['./chat.component.scss']
})
export class ChatComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
