// import { Routes } from "@angular/router";
// import { UserListingComponent } from "./user-listing/user-listing.component";
// import { UserDetailsComponent } from "./user-details/user-details.component";

// export const USER_ROUTES: Routes = [
//   {
//     path: "",
//     component: UserListingComponent
//   },
//   {
//     path: ":id",
//     component: UserDetailsComponent
//   }
// ];
