import { Routes } from "@angular/router";
import { BuilderComponent } from "./builder.component";

export const BUILDER_ROUTES: Routes = [
  {
    path: "",
    component: BuilderComponent
  }
];
