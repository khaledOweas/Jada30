import { Component } from '@angular/core';

@Component({
  selector: 'app-permission-details',
  standalone: true, // Generated Stand-Alone Component
  templateUrl: './permission-details.component.html',
  styleUrls: ['./permission-details.component.scss']
})
export class PermissionDetailsComponent {

}
